=== dadan-integrator-block ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: dadan, Video, Embed
Requires at least: 6.7
Tested up to: 6.8.2
Stable tag: 0.9.5
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Allows you to add https://www.dadan.io/ videos embedded on your WordPress sites easily and quickly
== Description ==

Allows you to add dadan.io videos embedded on your WordPress sites easily and quickly

== Installation ==

1. Upload the `dadan-integrator-block` folder to the `/wp-content/plugins/` directory.
2. Go to a Guttenberg page you will now have a new block.
3. use the configurator to modify the use bubbles embed

== Frequently Asked Questions ==

== Changelog ==
= 0.9.4 13 August 2025 =
New: Final Update Test

= 0.9.3 13 August 2025 =
New: First Full Update Test
New: Readme Updates

= 0.9.2 14 August 2025 =
New: Second Automatic Update Test

= 0.9.1 14 August 2025 =
New: First Automatic Update Test

= 0.9 12 August 2025 =
New: Initial Release