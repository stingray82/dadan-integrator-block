=== dadan-integrator-block ===
Tags: dadan, Video, Embed
Requires at least: 6.7
Tested up to: 7.1.3
Stable tag: 1.0.2
Requires PHP: 8.0

Allows you to add https://www.dadan.io/ videos embedded on your WordPress sites easily and quickly
== Description ==

Allows you to add dadan.io videos embedded on your WordPress sites easily and quickly

== Installation ==

1. Upload the `dadan-integrator-block` folder to the `/wp-content/plugins/` directory.
2. Go to a Guttenberg page you will now have a new block.
3. use the configurator to modify the use bubbles embed

== Frequently Asked Questions ==

== Changelog ==
= 1.0.2 16 October 2026 =
Updated: UUPD Dependency Updated to Version 2.1 Stable
Updated: Deploy Methodology

= 1.0.1 24 July 2026 =
Updated: UUPD Dependency Updated to Version 2.0 Stable

= 1.0 23 March 2026 =
Update: Updater to 2.0-Alpha
Update: Compatibility
New: Final 1.0 Release

= 0.9.5 15 August 2025 =
Tweaked: Fill Container is now default setting 

= 0.9.4 14 August 2025 =
New: Final Update Test

= 0.9.3 14 August 2025 =
New: First Full Update Test
New: Readme Updates

= 0.9.2 13 August 2025 =
New: Second Automatic Update Test

= 0.9.1 13 August 2025 =
New: First Automatic Update Test

= 0.9 12 August 2025 =
New: Initial Release